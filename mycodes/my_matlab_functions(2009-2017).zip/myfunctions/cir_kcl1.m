
function[icurrent] = kcl(vol,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11)

if nargin <3 , r2=0; icurrent = (r1)/vol ; end
if nargin <4 , r3=0; icurrent = (r1+r2)/vol ; end
if nargin <5 , r4=0; icurrent = (r1+r2+r3)/vol ; end 
if nargin <6 , r5=0; icurrent = (r1+r2+r3+r4)/vol ; end
if nargin <7 , r6=0; icurrent = (r1+r2+r3+r4+r5)/vol ; end
if nargin <8 , r7=0; icurrent = (r1+r2+r3+r4+r5+r6)/vol ; end
if nargin <9 , r8=0; icurrent = (r1+r2+r3+r4+r5+r6+r7)/vol ; end
if nargin <10 , r9=0; icurrent = (r1+r2+r3+r4+r5+r6+r7+r8)/vol ; end
if nargin <11 ,r10=0; icurrent = (r1+r2+r3+r4+r5+r6+r7+r8+r9)/vol ; end
if nargin <12 ,       icurrent = (r1+r2+r3+r4+r5+r6+r7+r8+r9+r10)/vol; end


