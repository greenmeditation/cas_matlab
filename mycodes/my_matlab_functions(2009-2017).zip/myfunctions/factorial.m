

function a1=factorial(a)

 n=a-1;
 a1=a;
 for i=1:n,   
   if a ~=1,     
     a1=a1*(a-i);
   elseif a==1,
     a1=1;	   
   end
       
 end	 
