

function[var] = admitance_C(c,w)
  
    var = w*c*sqrt(-1);



