

function[i,v,p]=cir_serial_v(v,aR)
i=v/sum(aR);
v=aR(1:end)*i;
p=v(1:end)*i;



