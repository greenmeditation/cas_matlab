%
%  theme:hyperbolic equation
%  Advanced Engineering Mathematics 
%

 clear all;
 aU=zeros(10,10);
 
% initial location
  
 for i=2:9,
     h = i/10;
    aU(1,i) = sin(pi*h);  
 end

 for i=1:8,
     aU(2,i+1)= 0.5*(aU(1,i)+aU(1,i+2));
 end

 for i=3:10
   for j=3:10,
      aU(i,j-1) = aU(i-1,j-2) + aU(i-1,j) - aU(i-2,j-1);
   end
 end

surf(aU);
