

function[aA,n1]=find_z_z0(qz);
 p1=factor(qz);
 p2=solve(p1);
 ch1=char(p1);
 [row,col]=size(ch1);
 aA=zeros(1:7);
 n1=ch1(end);
 n1=str2num(n1);
 n=length(n1);
 if 0==n,
    n1=1;
 else
    n1=n1;
end    
 aA=ch1(end-6:end);
