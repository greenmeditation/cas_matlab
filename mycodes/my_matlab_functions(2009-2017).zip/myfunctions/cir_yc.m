

function[var] = admitance_C(w,c)
  
    var = w*c*sqrt(-1);



