

 % ----------------------------------------------------------------
 % c
 % chap 1. applied mathematics
 % section :  electtric circuits
 %
 clear all;

 % c
