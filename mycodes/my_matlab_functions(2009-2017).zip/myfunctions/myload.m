

%------------------------------------------------
% * file_name :   read_nr_matrix
% * theme :
% * kw    :
% * from  :
% * ref   :
%------------------------------------------------

function[line,row2,aA1,aB1]=read_nr_matrix(f1,line)
disp(line);
for i=1:2,
   disp(fgetl(f1));
end
[row_size]=fgetl(f1);
row_size=str2num(row_size);
row1=row_size(1,1);
row2=row_size(1,2);
aA1=zeros(row1,row1);
aB1=zeros(row2,row1);
disp( fgetl(f1));
for i=1:row1,
   aA1(i,:)=str2num(fgetl(f1));
   fprintf('%10.5f', aA1(i,:));
   fprintf('\n');
end
disp(fgetl(f1));
for i=1:row2
   aB1(i,:)=str2num(fgetl(f1));
   fprintf('%10.5f', aB1(i,:));
   fprintf('\n');
end

% clear row_size row1 row2 aA1 aB1;
line=fgetl(f1);
