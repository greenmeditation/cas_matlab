
function[val1,current,val2] = pc(aR,voltage,current)

[row,col] = size(aR);
 va12 = zeros(1,col);
 if nargin == 1,
    val1 = prod(aR)/sum(aR);
 end
 if nargin == 2,
    val1 =  prod(aR)/sum(aR);
    current = voltage/val1;
    for i =1:col,
        val2(i) = ((prod(aR)/aR(i))/sum(aR))*current;    
    end     
 end
 
 if nargin == 3,
      val1 =  prod(aR)/sum(aR);
      % current = voltage/val1;
      for i =1:col,
        val2(i) = ((prod(aR)/aR(i))/sum(aR))*current;    
      end
       
 end
