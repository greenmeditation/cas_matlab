
function[val1,current,val2] = sc1(aR,voltage)

 [row,col] = size(aR);
 val2 = zeros(1,col);
 if nargin == 1,
 val1 = sum(aR);
 end
 if nargin == 2,
    val1 = sum(aR);
    current = voltage/val1;
    for i=1:col,
      val2(i) = aR(i)*current;
    end
 end
   
 