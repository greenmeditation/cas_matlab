
function[ var ] = vecmul(aA, aB)

  var = aA.*aB; 
   