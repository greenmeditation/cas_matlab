
% *************** Mesh analysis ************

aMesh=[5 3 4 0 3;3 4 0 3 4];
[row, col]=size(aMesh);
aA=zeros(1:row,1:col-1);
aV=aMesh(1:row, 1);

for i=1:row,
   for j=2:col,
       if aMesh(i,j) ~= 0,
          aA(i,j)=sum(aMesh(i,j));
       end
   end
end