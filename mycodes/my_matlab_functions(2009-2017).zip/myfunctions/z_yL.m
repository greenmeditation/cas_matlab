

function[var] = admitance_L(l,w)
   var = 1/(w*l*sqrt(-1));



