

function[z1]=cir_phase(z)
   a=sqrt(real(z)^2+imag(z)^2);
   p=rad2deg( atan(imag(z)/real(z)) );
   sprintf('amp');
   z1=[a p];
   
