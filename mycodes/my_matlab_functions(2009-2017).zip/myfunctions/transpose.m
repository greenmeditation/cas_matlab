

function[aAt] = transpose(aA)

  aAt = aA';    