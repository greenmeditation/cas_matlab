

function[v,v1,p]=cir_find_v(i,aR)
   v=sum(aR)*i;
   v1=aR.*i;
   p=v1.*i;

