function[var] = sub(aA,aB)
var = aA - aB;
