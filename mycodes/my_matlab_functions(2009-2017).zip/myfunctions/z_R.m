

function[var] = zimpedance_R(r,w)



