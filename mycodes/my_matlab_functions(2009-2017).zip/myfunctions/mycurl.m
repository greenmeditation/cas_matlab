function a=mycurl(f)
   syms x y z;
   [row,col]=size(f);

   if col == 1,
      disp('more insert factor');
   elseif  col==2,
     a=diff(f(2),x)-diff(f(1),y);
   elseif  col==3,
      a1=diff(f(3),y)-diff(f(2),z);
      a2=diff(f(2),z)-diff(f(3),x);
      a3=diff(f(2),x)-diff(f(1),y);
      a=a1+a2+a3;
   else
	disp(' ');   
   end



