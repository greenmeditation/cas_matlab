

function[var] = zimpedance_L(w,l)
  var = w*l*sqrt(-1);


