

%------------------------------------------------
% * file_name :    nr_rk4.m
% * theme :
% * kw    :
% * from  :
% * ref   :
%------------------------------------------------

function[yout]=nr_rk4(y,dydx,n,x,h,yout,feq)

  dym=zeros(1,n);
  dyt=zeros(1,n);
  yt=zeros(1,n);
  %yout=zeros(n,1);
  hh=h*0.5;
  h6=h/6.0;
  xh=x+hh;
  dydx=feval(feq,x,y,dydx);
  for i=1:n,
    yt(i)=y(i)+hh*dydx(i);
  end
  dyt=feval(feq,xh,yt,dyt);
  for i=1:n,
    yt(i)=y(i)+hh*dyt(i);
  end
  dym=feval(feq,xh,yt,dym);
  for i=1:n,
    yt(i)=y(i)+h*dym(i);
    dym(i)=dym(i)+dyt(i);
  end
  dyt=feval(feq,x+h,yt,dyt);
  for i=1:n,
    yout(1,i)=y(i)+h6*(dydx(i)+dyt(i)+2.0*dym(i));
  end
  clear yt dyt dym;
