
function[icurrenttage] = kcl(icurrent,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11)

if nargin <3 , r2=0; icurrenttage = (r1)*icurrent ; end
if nargin <4 , r3=0; icurrenttage = (r1+r2)*icurrent ; end
if nargin <5 , r4=0; icurrenttage = (r1+r2+r3)*icurrent ; end 
if nargin <6 , r5=0; icurrenttage = (r1+r2+r3+r4)*icurrent ; end
if nargin <7 , r6=0; icurrenttage = (r1+r2+r3+r4+r5)*icurrent ; end
if nargin <8 , r7=0; icurrenttage = (r1+r2+r3+r4+r5+r6)*icurrent ; end
if nargin <9 , r8=0; icurrenttage = (r1+r2+r3+r4+r5+r6+r7)*icurrent ; end
if nargin <10 , r9=0; icurrenttage = (r1+r2+r3+r4+r5+r6+r7+r8)*icurrent ; end
if nargin <11 ,r10=0; icurrenttage = (r1+r2+r3+r4+r5+r6+r7+r8+r9)*icurrent ; end
if nargin <12 ,       icurrenttage = (r1+r2+r3+r4+r5+r6+r7+r8+r9+r10)*icurrent; end


