

function[var] = zimpedance_L(l,w)
  var = w*l*sqrt(-1);


