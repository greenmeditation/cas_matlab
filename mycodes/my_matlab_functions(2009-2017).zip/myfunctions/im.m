
function[i] = imaginumber(v1)
    i =  sqrt(-1).*(v1);
