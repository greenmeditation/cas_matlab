

function[aA]=fgetl(str)
    aA=fgetline(str);
