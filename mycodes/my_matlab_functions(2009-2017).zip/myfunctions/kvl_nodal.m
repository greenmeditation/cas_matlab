
 function[]=nodal(aNodal)
 [row,col] = size(aMesh);

 #aV = zeros(1:row);
 #aI = zeros(1:row);
 aIcur = aMesh(1:row,1:col-1);
 aV = aMesh(1:row,col);
 aI = aA\aV;



