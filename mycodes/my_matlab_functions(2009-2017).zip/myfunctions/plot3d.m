
function[] = plot3d(x,y,feq)

  [x,y]=meshgrid(x,y);
  mesh(x,y,feq);
