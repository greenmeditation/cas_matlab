function[var] = div(aA,aB)

   var = aA\aB;
