

function aA=mynormal(aA)


