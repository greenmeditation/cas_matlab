

function[a,p]=cir_phase(z1,z2)
   a=real(z1)/real(z2);
   p=imag(z1)-imag(z2);
   
