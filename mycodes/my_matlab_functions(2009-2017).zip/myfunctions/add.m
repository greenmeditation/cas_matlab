function[ var] = add( aA,aB)

 var = aA + aB;
