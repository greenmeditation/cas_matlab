

function[var] = zimpedance_C(c,w)

   var = 1/(w*c*sqrt(-1));



