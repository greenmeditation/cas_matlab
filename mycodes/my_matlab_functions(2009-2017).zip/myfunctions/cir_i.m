

function[i,v]=cir_find_i(string,v,aR)

if 1==strcmp('s',string)

  i=v/sum(aR); 
  v=aR(1:end)*i;

elseif 1==strcmp('p',string)
		
else
	   	disp(' ');
end		


