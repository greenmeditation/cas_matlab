
function[var] = mul(aA,aB)

 var = aA * aB;