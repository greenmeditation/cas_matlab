
% *************** Mesh analysis ************

% aMesh=[5 3 4 0 3;3 4 0 3 4];
% [row, col]=size(aMesh);
% aA=zeros(1:row,1:col-1);
% aV=aMesh(1:row,1);

function[aI,aA] = kvl_mesh(aMesh)
%kvl_mesh(aA)
[row,col] = size(aMesh);

aV = zeros(1:row);
aI = zeros(1:row);
aA = aMesh(1:row,1:col-1);
aV = aMesh(1:row,col);
aI = aA\aV;







