

function[var] = admitance_L(w,l)
   var = 1/(w*l*sqrt(-1));



