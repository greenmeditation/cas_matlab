



function[z]=cir_z(a)
    r1=real(a);
    i1=imag(a);
    z=[r1 i1];
    
    