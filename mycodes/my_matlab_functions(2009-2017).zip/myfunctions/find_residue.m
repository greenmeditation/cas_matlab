function[aA]=find_residue(pz,qz,a1,n)
 syms x y z
 p1=factor(qz);
 z_z0=a1;
 n1=n;
 z0=solve(z_z0);
 eq1=(z_z0)/p1;
 n1=length(z0);
 aA=zeros(1:n1);
 res=(1/factorial(n1-1))*diff(eq1*pz,n1-1,z);
 aA(1:n1)=subs(res,z,z0(1:end));



