
 function[aVtotal,aVol]=nodal(aIcur,aResistance)
 [row,col] = size(aResistance);

 %aV = zeros(1:row);
 %aI = zeros(1:row);
 %aIcur = aMesh(1:row,1:col-1);
 aVtotal = sum(aResistance) * aIcur;
 aVol = aResistance.*aIcur ;
 



