

function[a]=cir_c(aA)
	a=sum(aA);


