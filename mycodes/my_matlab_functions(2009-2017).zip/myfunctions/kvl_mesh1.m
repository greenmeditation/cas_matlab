
% *************** Mesh analysis ************

% aMesh=[5 3 4 0 3;3 4 0 3 4];
% [row, col]=size(aMesh);
% aA=zeros(1:row,1:col-1);
% aV=aMesh(1:row,1);

function[aItotal,aI] = kvl_mesh(aResistance)
%kvl_mesh(aA)
[row,col] = size(aResistance);

%aV = zeros(1:row);
%aI = zeros(1:row);
%aA = aMesh(1:row,1:col-1);
%aV = aMesh(1:row,col);
%aI = aA\aV;
aItotal = aResistance;
aI = aResistance;







