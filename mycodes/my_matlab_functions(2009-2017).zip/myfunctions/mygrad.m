

function aA=mygradient(a1)
syms x y z;
p1=diff(a1,x);
p2=diff(a1,y);
p3=diff(a1,z);
aA=[p1,p2,p3];


