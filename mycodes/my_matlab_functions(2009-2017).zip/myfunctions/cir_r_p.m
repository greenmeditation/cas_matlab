

function[a]=cir_c(aR)

    a1=sum(1./aR);
	a=1/a1;



