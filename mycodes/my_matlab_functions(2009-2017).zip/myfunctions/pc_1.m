

% *  circuit analysis 
%
%
% ******** example ******
% r1=2;
% r2=10;
% r3=5;
% v1=5;

function[r] = Rp(r1,r2,r3,,r4,r5,r6,r7,r8,r9,r10)

if nargin <2 ,r1a=r1;  r=r1a ; end
if nargin <3 ,r1a=r1;  r2a=r2 ; ...
              r3a=1; r3=0; r = (r1a*r2a)/(r1+r2) ; end
if nargin <4 ,r1a=r1;  r2a=r2; r3a=r3;  ...  
              r4=0; r4a=1;  r = (r1a*r2a*r3a)/(r1+r2+r3) ; end 
if nargin <5 ,r1a=r1;  r2a=r2; r3a=r3; r4a=r4; ...
             r5=0; r5a=1;    r = (r1a*r2a*r3a*r4a)/(r1+r2+r3+r4) ; end
if nargin <6 ,r1a=r1;  r2a=r2; r3a=r3; r4a=r4; r5a=r5; ...
              r6=0; r6a=1;    r = (r1a*r2a*r3a*r4a*r5a)/(r1+r2+r3+r4+r5) ; end
if nargin <7 ,r1a=r1;  r2a=r2; r3a=r3; r4a=r4; r5a=r5; r6a=r6; ...
              r7=0; r7a=1;     r = (r1a*r2a*r3a*r4a*r5a*r6a)/(r1+r2+r3+r4+r5+r6) ;end
if nargin <8 ,r1a=r1;  r2a=r2; r3a=r3; r4a=r4; r5a=r5; r6a=r6; r7a=r7; ...
              r8=0; r8a=1;     r = (r1a*r2a*r3a*r4a*r5a*r6a*r7a)/(r1+r2+r3+r4+r5+r6+r7) ; end
if nargin <9 ,ra1=r1; r2a=r2; r3a=r3; r4a=r4; r5a=r5; r6a=r6; r7a=r7;r8a=r8; ...
              r9=0; r9a=1;     r = (r1a*r2a*r3a*r4a*r5a*r6a*r7a*r8a)/(r1+r2+r3+r4+r5+r6+r7+r8) ; end
if nargin <10 ,ra1=r1;  r2a=r2; r3a=r3; r4a=r4; r5a=r5; r6a=r6; r7a=r7;r8a=r8;r9a=r9; ...
              r10=0; r10a=1;   r =(r1a*r2a*r3a*r4a*r5a*r6a*r7a*r8a*r9a)/(r1+r2+r3+r4+r5+r6+r7+r8+r9) ; end
if nargin <11 ,r1a=r1;   r2a=r2; r3a=r3; r4a=r4; r5a=r5; r6a=r6;r7a=r7;r8a=r8;r9a=r9;r10a=r10; ...
               r = (r1a*r2a*r3a*r4a*r5a*r6a*r7a*r8a*r9a*r10a)/(r1+r2+r3+r4+r5+r6+r7+r8+r9+r10) ; end



 