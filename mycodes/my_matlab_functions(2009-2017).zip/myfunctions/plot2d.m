
function[] = plot2d(var1,var2,var3)

 plot(var1,var2,var3)
