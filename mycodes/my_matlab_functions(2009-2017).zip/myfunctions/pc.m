

% *  circuit analysis 
%
%
% ******** example ******
% r1=2;
% r2=10;
% r3=5;
% v1=5;
% 
function[r] = Rp(r1,r2,r3,r4,r5,r6,r7,r8,r9,r10)

if nargin <2 , r2=0; rp = r1 ; end
if nargin <3 , r3=0; rp = r1+r2 ; end
if nargin <4 , r4=0; rp = r1+r2+r3 ; end 
if nargin <5 , r5=0; rp = r1+r2+r3+r4 ; end
if nargin <6 , r6=0; rp = r1+r2+r3+r4+r5 ; end
if nargin <7 , r7=0; rp = r1+r2+r3+r4+r5+r6; end
if nargin <8 , r8=0; rp = r1+r2+r3+r4+r5+r6+r7; end
if nargin <9 , r9=0; rp = r1+r2+r3+r4+r5+r6+r7+r8; end
if nargin <10, r10=0;  rp = r1+r2+r3+r4+r5+r6+r7+r8+r9; end
if nargin <11,  rp = r1+r2+r3+r4+r5+r6+r7+r8+r9+r10; end

if nargin <2 , r2=1; rs = r1 ; end
if nargin <3 , r3=1; rs = r1*r2 ; end
if nargin <4 , r4=1; rs = r1*r2*r3 ; end 
if nargin <5 , r5=1; rs = r1*r2*r3*r4 ; end
if nargin <6 , r6=1; rs = r1*r2*r3*r4*r5 ; end
if nargin <7 , r7=1; rs=  r1*r2*r3*r4*r5*r6 ; end
if nargin <8 , r8=1; rs=  r1*r2*r3*r4*r5*r6*r7; end
if nargin <9 , r9=1; rs=  r1*r2*r3*r4*r5*r6*r7*r8; end
if nargin <10, r10=1; rs=  r1*r2*r3*r4*r5*r6*r7*r8*r9; end
if nargin <11,  rs=  r1*r2*r3*r4*r5*r6*r7*r8*r9*r10; end

if nargin <2 ,  r = r1 ; end
if nargin <3 ,  r = rs/rp ; end
if nargin <4 ,  r = rs/rp ; end 
if nargin <5 ,  r = rs/rp ; end
if nargin <6 ,  r = rs/rp ; end
if nargin <7 ,  r = rs/rp ; end
if nargin <8 ,  r = rs/rp ; end
if nargin <9 ,  r = rs/rp ; end
if nargin <10,  r = rs/rp ; end
if nargin <11,  r = rs/rp ; end





 