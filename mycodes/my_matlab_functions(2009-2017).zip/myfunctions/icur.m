
function[i1] = icurrent(i)

   i1 = i;

