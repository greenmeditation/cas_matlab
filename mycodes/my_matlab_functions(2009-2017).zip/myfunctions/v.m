
function[volt] = voltage(v1)
volt = v1;


