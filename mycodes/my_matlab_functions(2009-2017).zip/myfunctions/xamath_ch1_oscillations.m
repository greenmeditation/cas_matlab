

% ----------------------------------------------------------------
% c
% chap 1. applied mathematics
% section :  forced oscillations
%

% modeling : free oscillations 

w = 9.899;
delta =0;
c = 0.15;
feq1 = inline('cos(w*t - delta)', 'w','t','delta');
feq2 = c*feq1;



