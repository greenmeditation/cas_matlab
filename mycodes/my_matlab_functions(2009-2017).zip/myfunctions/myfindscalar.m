

function a=myfindscalar(aA);

syms x y z fx fy fz;

[row1,col1]=size(aA);

if col1 == 1,
	disp(' ');
elseif col1==2,
	p1=int(aA(1),x)+fy;
	p2=diff(p1,y)+int(aA(2),y);
	a=subs(p1,fy,p2);
elseif col1==3,
	p1=int(aA(1),x)+fy+fz;
	p2=diff(p1,y)+int(aA(2),y);
	p3=diff(p1,z)+int(aA(3),z);
	a=subs(p1,{fy,fz},{p2,p3});
else
   disp('  ')'

end   
