

function[var] = zimpedance_R(r,w)
   var=((real(r)-im*imag(x))/(real(r)^2 + imag(r)^2))



