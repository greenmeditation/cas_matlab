

%------------------------------------------------
% * file_name : cir_i_p.m                                  
% * theme : find i input voltage paralle R                                      
% * kw    : kvl                                      
% * from  :                                       
% * ref   :                                       
%------------------------------------------------

function[R,cur,p] = pc(v,aR)

  col=length(aR);
  R=cir_r_p(aR);
  cur=zeros(1,col);
  p=zeros(1,col);
  
  cur(1:end)=v./aR(1:end);    
 
  p(1:end)=cur(1:end)*v;
