

function[var] = zimpedance_C(w,c)

   var = 1/(w*c*sqrt(-1));



