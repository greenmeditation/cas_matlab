
function[cur,v,R,p] = pc(cur1,aR)

col=length(aR);
% va12 = zeros(1,col);
% if nargin == 1,
%    val1 = prod(aR)/sum(aR);
% end
% if nargin == 2,
  cur=zeros(1,col);
  p=zeros(1,col);

  R=sum(1./aR);
  for i =1:col,
        cur(i)=((1/aR(i))*cur1)/R;    
  end        
 
  v=cur1/R;
  p=cur(1:end)*v;
