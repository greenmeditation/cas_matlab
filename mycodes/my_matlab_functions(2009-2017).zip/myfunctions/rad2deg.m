


function[a1]=radtodeg(a)
    a1=(a*180)/pi;
    

