


function[aA]=myresidue(pz,qz)
 syms x y z 
 dqz=diff(qz,z);
 a1=char(dqz);
 if  1==ischar(a1),
	 eq1=pz/dqz;
	 p1=factor(dqz);
	 p2=solve(p1);
	 n=length(p2);
	 aA=zeros(1,n);
	 aA(1:n)=subs(eq1,z,p2(1:n));
 
	 for i=1:n,
	   disp(aA(i));
	 end   
 elseif  	 
