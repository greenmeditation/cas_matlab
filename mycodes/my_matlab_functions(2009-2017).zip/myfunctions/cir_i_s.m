

%------------------------------------------------
% * file_name :  cir_i_s.m                                 
% * theme : find i                                      
% * kw    : kvl at serial resistance                                      
% * from  :                                       
% * ref   :                                       
%------------------------------------------------

function[i,v]=cir_find_i(v,aR)
i=v/sum(aR);
v=aR(1:end)*i;



