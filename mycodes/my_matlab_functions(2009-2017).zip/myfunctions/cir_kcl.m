
function[current,voltage] = kcl(aR,voltage)
[raw,col] = size(aR);
aR1 = zeros(1,col);
current = sum(aR)/voltage;
for i=1:col,
   aR1(i).*current;
end  
